import React from "react";
import Svg, { Circle, Ellipse, Path } from "react-native-svg";

export function SnakeArt({
  color = "#80C55F",
  accent = "#528B4B",
  variant = 0,
  size = 88,
  locked = false,
  secret = false,
}: {
  color?: string;
  accent?: string;
  variant?: number;
  size?: number;
  locked?: boolean;
  secret?: boolean;
}) {
  const body = locked ? "#D2D0C5" : color;
  const detail = locked ? "#AAA99F" : accent;
  const ink = locked ? "#8E9185" : "#62493C";
  const markings = Math.abs(variant) % 6;
  const showSecret = secret && !locked;

  return (
    <Svg
      width={size}
      height={size * 0.88}
      viewBox="0 0 100 88"
      accessibilityLabel={
        showSecret ? "งูการ์ตูนสีซีเคร็ต" : "ภาพงูการ์ตูนลายเส้นนิทาน"
      }
    >
      <Ellipse cx="49" cy="76" rx="35" ry="6" fill="#806247" opacity="0.12" />
      <Path
        d="M18 67 C11 62 9 54 12 47 C16 37 26 33 36 36 C47 39 52 50 47 58 C43 65 33 66 28 60 C23 54 26 46 32 44 C38 42 43 46 42 51"
        fill="none"
        stroke={ink}
        strokeWidth="20"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M18 67 C11 62 9 54 12 47 C16 37 26 33 36 36 C47 39 52 50 47 58 C43 65 33 66 28 60 C23 54 26 46 32 44 C38 42 43 46 42 51"
        fill="none"
        stroke={body}
        strokeWidth="15"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M42 52 C47 42 48 32 57 29"
        fill="none"
        stroke={ink}
        strokeWidth="20"
        strokeLinecap="round"
      />
      <Path
        d="M42 52 C47 42 48 32 57 29"
        fill="none"
        stroke={body}
        strokeWidth="15"
        strokeLinecap="round"
      />
      <Path
        d="M24 69 C32 72 41 70 46 64"
        fill="none"
        stroke="#F7E7B8"
        strokeWidth="4"
        strokeLinecap="round"
        opacity="0.95"
      />
      {markings === 0 ? (
        <Path
          d="M17 48 Q21 44 25 47 M32 61 Q37 57 41 60 M45 42 Q49 38 53 41"
          fill="none"
          stroke={detail}
          strokeWidth="2.8"
          strokeLinecap="round"
        />
      ) : null}
      {markings === 1 ? (
        <Path
          d="M18 53 Q23 55 26 50 M32 41 Q35 45 39 43 M42 56 Q46 53 48 49"
          fill="none"
          stroke={detail}
          strokeWidth="2.6"
          strokeLinecap="round"
        />
      ) : null}
      {markings === 2 ? (
        <>
          <Circle cx="22" cy="53" r="2.2" fill={detail} />
          <Circle cx="35" cy="48" r="2.2" fill={detail} />
          <Circle cx="43" cy="58" r="2.2" fill={detail} />
        </>
      ) : null}
      {markings === 3 ? (
        <Path
          d="M17 49 L22 44 L27 49 L32 44 L37 49 M32 61 L37 56 L42 61 L47 56"
          fill="none"
          stroke={detail}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      ) : null}
      {markings === 4 ? (
        <>
          <Path d="M18 53 Q21 48 24 53 Q21 58 18 53Z" fill={detail} />
          <Path d="M32 45 Q35 40 38 45 Q35 50 32 45Z" fill={detail} />
          <Path d="M41 59 Q44 54 47 59 Q44 64 41 59Z" fill={detail} />
        </>
      ) : null}
      {markings === 5 ? (
        <>
          <Circle cx="20" cy="50" r="1.8" fill={detail} />
          <Circle cx="27" cy="59" r="1.8" fill={detail} />
          <Circle cx="37" cy="43" r="1.8" fill={detail} />
          <Circle cx="44" cy="56" r="1.8" fill={detail} />
        </>
      ) : null}
      {showSecret ? (
        <>
          <Path
            d="M16 57 L18 53 L20 57 L24 58 L20 60 L18 64 L16 60 L13 59Z"
            fill="#FFE16E"
          />
          <Path
            d="M36 39 L38 35 L40 39 L44 40 L40 42 L38 46 L36 42 L32 41Z"
            fill="#FFF2A6"
          />
          <Circle cx="48" cy="54" r="2" fill="#F7A4D2" />
        </>
      ) : null}
      <Ellipse cx="70" cy="29" rx="23" ry="19" fill={ink} />
      <Ellipse cx="70" cy="28" rx="21" ry="17" fill={body} />
      <Path
        d="M55 37 Q69 47 84 37 Q78 48 65 47 Q58 44 55 37Z"
        fill="#F7E7B8"
        stroke={ink}
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <Path
        d="M59 22 Q64 19 67 22"
        fill="none"
        stroke={ink}
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <Path
        d="M75 21 Q80 18 83 21"
        fill="none"
        stroke={ink}
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <Ellipse cx="64" cy="27" rx="4" ry="5" fill="#FFFDF6" />
      <Ellipse cx="79" cy="27" rx="4" ry="5" fill="#FFFDF6" />
      <Circle cx="65" cy="28" r="2.2" fill="#473B35" />
      <Circle cx="80" cy="28" r="2.2" fill="#473B35" />
      <Circle cx="64.2" cy="27" r="0.8" fill="#FFFFFF" />
      <Circle cx="79.2" cy="27" r="0.8" fill="#FFFFFF" />
      <Circle cx="57" cy="34" r="3.2" fill="#F39C8D" opacity="0.82" />
      <Circle cx="84" cy="34" r="3.2" fill="#F39C8D" opacity="0.82" />
      <Path
        d="M68 36 Q72 40 76 36"
        fill="none"
        stroke={ink}
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      {showSecret ? (
        <>
          <Path
            d="M58 13 L62 5 L67 12 L72 3 L77 12 L83 6 L86 17 Q72 14 58 17Z"
            fill="#FFD45D"
            stroke={ink}
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
          <Circle cx="67" cy="11" r="1.6" fill="#F28EB8" />
          <Circle cx="78" cy="11" r="1.6" fill="#73C9DF" />
        </>
      ) : markings === 3 ? (
        <>
          <Path d="M48 19 Q70 -1 92 20 Q72 12 48 19Z" fill={ink} />
          <Path d="M50 17 Q70 1 90 18 Q70 12 50 17Z" fill="#D99A59" />
          <Path
            d="M52 20 Q71 17 89 21"
            fill="none"
            stroke="#F6D591"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </>
      ) : markings === 1 ? (
        <>
          <Circle
            cx="56"
            cy="15"
            r="5"
            fill="#F28CAF"
            stroke={ink}
            strokeWidth="1.3"
          />
          <Circle
            cx="65"
            cy="15"
            r="5"
            fill="#F28CAF"
            stroke={ink}
            strokeWidth="1.3"
          />
          <Circle
            cx="60.5"
            cy="18"
            r="3"
            fill="#F4C65E"
            stroke={ink}
            strokeWidth="1"
          />
        </>
      ) : (
        <Path
          d="M52 17 Q60 9 68 15 Q75 7 88 17"
          fill="none"
          stroke={detail}
          strokeWidth="3"
          strokeLinecap="round"
        />
      )}
    </Svg>
  );
}
