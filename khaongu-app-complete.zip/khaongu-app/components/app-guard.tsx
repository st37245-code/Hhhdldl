import React, { useState } from "react";
import { ActivityIndicator, Pressable, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";

import { ScaledText as Text } from "@/components/scaled-text";
import { useAppStore } from "@/hooks/app-store";
import { ActionButton, C, ConfirmDialog } from "@/components/primitives";

export function AppGuard() {
  const { ready, storageError, recoverStorage } = useAppStore();
  const [confirmReset, setConfirmReset] = useState(false);
  if (ready && !storageError) return null;

  if (!ready) {
    return (
      <View
        style={{
          position: "absolute",
          top: 0,
          right: 0,
          bottom: 0,
          left: 0,
          zIndex: 100,
          backgroundColor: C.cream,
          alignItems: "center",
          justifyContent: "center",
          gap: 15,
          padding: 24,
        }}
      >
        <Ionicons name="leaf" size={34} color={C.forest} />
        <ActivityIndicator color={C.forest} />
        <Text style={{ color: C.forest, fontSize: 14, fontWeight: "700" }}>
          กำลังเปิดสมุดนักสำรวจ...
        </Text>
      </View>
    );
  }

  const isReadError = storageError === "read";
  return (
    <View
      style={{
        position: "absolute",
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        zIndex: 100,
        backgroundColor: C.cream,
        alignItems: "center",
        justifyContent: "center",
        padding: 24,
      }}
    >
      <View
        style={{
          width: "100%",
          maxWidth: 390,
          backgroundColor: C.paper,
          borderRadius: 26,
          borderWidth: 1,
          borderColor: C.line,
          padding: 24,
          gap: 14,
        }}
      >
        <View
          style={{
            width: 54,
            height: 54,
            borderRadius: 19,
            backgroundColor: C.orangeSoft,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Ionicons name="warning-outline" size={28} color={C.forest} />
        </View>
        <Text
          accessibilityRole="header"
          style={{ color: C.ink, fontSize: 21, fontWeight: "800" }}
        >
          {isReadError ? "เปิดข้อมูลเดิมไม่ได้" : "บันทึกข้อมูลไม่สำเร็จ"}
        </Text>
        <Text style={{ color: C.muted, fontSize: 14, lineHeight: 22 }}>
          {isReadError
            ? "ข้อมูลเดิมยังไม่ถูกล้าง ลองอ่านอีกครั้งได้ หากยังไม่สำเร็จเลือกเริ่มสมุดใหม่โดยยืนยันก่อนล้างข้อมูล"
            : "ตรวจพื้นที่ว่างในเครื่องแล้วลองบันทึกอีกครั้ง หรือเริ่มใหม่โดยยืนยันก่อนล้างข้อมูล"}
        </Text>
        <ActionButton
          label={isReadError ? "ลองอ่านอีกครั้ง" : "ลองบันทึกอีกครั้ง"}
          icon="refresh"
          onPress={() => void recoverStorage(false)}
        />
        <Pressable
          accessibilityRole="button"
          onPress={() => setConfirmReset(true)}
          style={{ alignSelf: "center", padding: 12 }}
        >
          <Text style={{ color: C.red, fontSize: 12, fontWeight: "700" }}>
            ล้างข้อมูลแล้วเริ่มใหม่
          </Text>
        </Pressable>
      </View>
      <ConfirmDialog
        visible={confirmReset}
        title="ล้างสมุดสำรวจ?"
        message="ข้อมูลเดิมจะถูกลบจากอุปกรณ์นี้และเริ่มใหม่ การล้างข้อมูลนี้ย้อนกลับไม่ได้"
        confirmLabel="ล้างและเริ่มใหม่"
        onCancel={() => setConfirmReset(false)}
        onConfirm={() => {
          setConfirmReset(false);
          void recoverStorage(true);
        }}
      />
    </View>
  );
}
