import React, { useState } from "react";
import {
  Image,
  ImageBackground,
  View,
  type ViewStyle,
} from "react-native";
import { SnakeArt } from "@/components/snake-art";

// Bundle the illustrations locally so the app also works on static hosts such as GitHub Pages.
export const storybookDioramaSource = require("../assets/images/khaongu/storybook-diorama.webp");
const storybookMascotSource = require("../assets/images/khaongu/storybook-mascot.webp");

export function StorybookDioramaBackground({
  children,
  height = 226,
  style,
}: React.PropsWithChildren<{ height?: number; style?: ViewStyle }>) {
  const [failed, setFailed] = useState(false);
  return (
    <ImageBackground
      source={
        failed
          ? require("../assets/images/khaongu/park-panorama.jpg")
          : storybookDioramaSource
      }
      onError={() => setFailed(true)}
      resizeMode="cover"
      style={[
        {
          width: "100%",
          height,
          overflow: "hidden",
          borderRadius: 28,
          backgroundColor: "#BEEAF1",
        },
        style,
      ]}
      imageStyle={{ borderRadius: 28 }}
    >
      {children}
    </ImageBackground>
  );
}

export function StorybookMascot({
  size = 92,
  style,
  accessibilityLabel = "งูน้อยนักสำรวจภาพวาด",
}: {
  size?: number;
  style?: ViewStyle;
  accessibilityLabel?: string;
}) {
  const [failed, setFailed] = useState(false);
  return (
    <View
      style={[
        { width: size, height: size, alignItems: "center", justifyContent: "center" },
        style,
      ]}
      accessibilityLabel={accessibilityLabel}
      accessibilityRole="image"
    >
      {failed ? (
        <SnakeArt size={size} color="#80C55F" accent="#528B4B" variant={4} />
      ) : (
        <Image
          source={storybookMascotSource}
          onError={() => setFailed(true)}
          accessibilityLabel={accessibilityLabel}
          resizeMode="contain"
          style={{ width: size, height: size }}
        />
      )}
    </View>
  );
}
