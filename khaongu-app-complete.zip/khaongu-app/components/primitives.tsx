import React from "react";
import {
  ActivityIndicator,
  Image,
  ImageBackground,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
  type ImageSourcePropType,
  type ImageStyle,
  type TextInputProps,
  type ViewStyle,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { ScaledText as Text } from "@/components/scaled-text";

export const C = {
  forest: "#49854F",
  forestDark: "#355F42",
  leaf: "#80C55F",
  leafSoft: "#EAF4D5",
  cream: "#FFF8E8",
  paper: "#FFFDF6",
  ink: "#4A3B34",
  muted: "#817167",
  line: "#E6C895",
  lake: "#87D9D8",
  sky: "#DDF4F5",
  peach: "#F5D5C0",
  orange: "#F4B942",
  orangeSoft: "#FFF0C7",
  red: "#D66C63",
  white: "#FFFFFF",
};

export function Screen({
  children,
  scroll = true,
  style,
}: React.PropsWithChildren<{ scroll?: boolean; style?: ViewStyle }>) {
  const content = <View style={[styles.inner, style]}>{children}</View>;
  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      {scroll ? (
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <ScrollView
            contentContainerStyle={styles.scrollContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {content}
          </ScrollView>
        </KeyboardAvoidingView>
      ) : (
        <View style={[styles.inner, { flex: 1 }, style]}>{children}</View>
      )}
    </SafeAreaView>
  );
}

export function PageHeader({
  title,
  subtitle,
  icon,
}: {
  title: string;
  subtitle?: string;
  icon?: keyof typeof Ionicons.glyphMap;
}) {
  return (
    <View style={styles.headerRow}>
      <View style={{ flex: 1 }}>
        {subtitle ? <Text style={styles.eyebrow}>{subtitle}</Text> : null}
        <Text accessibilityRole="header" style={styles.pageTitle}>
          {title}
        </Text>
      </View>
      {icon ? (
        <View style={styles.headerIcon}>
          <Ionicons name={icon} size={20} color={C.forest} />
        </View>
      ) : null}
    </View>
  );
}

export function SectionTitle({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <View style={styles.sectionTitleRow}>
      <Text accessibilityRole="header" style={styles.sectionTitle}>
        {title}
      </Text>
      {action && onAction ? (
        <Pressable accessibilityRole="button" onPress={onAction} hitSlop={10}>
          <Text style={styles.actionText}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function Card({
  children,
  style,
}: React.PropsWithChildren<{ style?: ViewStyle }>) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Pill({
  label,
  selected = false,
  onPress,
  icon,
}: {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
}) {
  const content = (
    <>
      {icon ? (
        <Ionicons name={icon} size={14} color={selected ? C.white : C.forest} />
      ) : null}
      <Text style={[styles.pillText, selected && styles.pillTextActive]}>
        {label}
      </Text>
    </>
  );
  return onPress ? (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[styles.pill, selected && styles.pillActive]}
    >
      {content}
    </Pressable>
  ) : (
    <View style={[styles.pill, selected && styles.pillActive]}>{content}</View>
  );
}

export function ActionButton({
  label,
  onPress,
  icon,
  tone = "primary",
  disabled = false,
  small = false,
  accessibilityLabel,
}: {
  label: string;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  tone?: "primary" | "soft" | "outline" | "danger";
  disabled?: boolean;
  small?: boolean;
  accessibilityLabel?: string;
}) {
  const toneStyle =
    tone === "primary"
      ? styles.btnPrimary
      : tone === "soft"
        ? styles.btnSoft
        : tone === "danger"
          ? styles.btnDanger
          : styles.btnOutline;
  const textStyle =
    tone === "primary" || tone === "danger"
      ? styles.btnTextWhite
      : styles.btnTextDark;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel ?? label}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        toneStyle,
        small && styles.buttonSmall,
        disabled && styles.disabled,
        pressed && !disabled && styles.pressed,
      ]}
    >
      {icon ? (
        <Ionicons
          name={icon}
          size={small ? 15 : 17}
          color={tone === "primary" || tone === "danger" ? C.white : C.forest}
        />
      ) : null}
      <Text style={[textStyle, small && { fontSize: 12 }]}>{label}</Text>
    </Pressable>
  );
}

export function BackHeader({
  title,
  onBack,
}: {
  title: string;
  onBack: () => void;
}) {
  return (
    <View style={styles.backHeader}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="ย้อนกลับ"
        onPress={onBack}
        style={styles.backButton}
      >
        <Ionicons name="chevron-back" size={22} color={C.forest} />
      </Pressable>
      <Text accessibilityRole="header" style={styles.backTitle}>
        {title}
      </Text>
      <View style={{ width: 42 }} />
    </View>
  );
}

export function SearchField({
  value,
  onChangeText,
  placeholder = "ค้นหา",
  ...props
}: TextInputProps) {
  return (
    <View style={styles.searchWrap}>
      <Ionicons name="search" size={18} color={C.muted} />
      <TextInput
        accessibilityLabel={placeholder}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#8A958A"
        style={styles.searchInput}
        returnKeyType="search"
        {...props}
      />
      {value ? (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="ล้างคำค้น"
          onPress={() => onChangeText?.("")}
        >
          <Ionicons name="close-circle" size={18} color={C.muted} />
        </Pressable>
      ) : null}
    </View>
  );
}

export function LoadingState({
  label = "กำลังเตรียมสมุดสำรวจ...",
}: {
  label?: string;
}) {
  return (
    <View style={styles.loading}>
      <ActivityIndicator color={C.forest} />
      <Text style={styles.bodyMuted}>{label}</Text>
    </View>
  );
}

export function OfflineBanner({
  message = "ออฟไลน์อยู่ — ข้อมูลในเครื่องยังใช้ได้",
}: {
  message?: string;
}) {
  return (
    <View accessibilityRole="text" style={styles.offlineBanner}>
      <Ionicons name="cloud-offline-outline" size={16} color={C.forest} />
      <Text style={styles.offlineText}>{message}</Text>
    </View>
  );
}

export function MascotImage({
  source,
  size = 92,
  style,
}: {
  source: ImageSourcePropType;
  size?: number;
  style?: ImageStyle;
}) {
  return (
    <Image
      accessibilityLabel="มาสคอตงูน้อยนักสำรวจ"
      source={source}
      resizeMode="contain"
      style={[{ width: size, height: size }, style]}
    />
  );
}

export function HeroPhoto({
  source,
  children,
  height = 220,
}: React.PropsWithChildren<{ source: ImageSourcePropType; height?: number }>) {
  return (
    <ImageBackground
      source={source}
      imageStyle={styles.heroImage}
      style={[styles.heroPhoto, { height }]}
    >
      <View style={styles.heroShade} />
      {children}
    </ImageBackground>
  );
}

export function FieldInput({
  label,
  ...props
}: TextInputProps & { label: string }) {
  return (
    <View style={{ gap: 8 }}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        placeholderTextColor="#8A958A"
        style={styles.input}
        {...props}
      />
    </View>
  );
}

export function ToggleRow({
  label,
  description,
  value,
  onValueChange,
}: {
  label: string;
  description?: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
}) {
  return (
    <Pressable
      accessibilityRole="switch"
      accessibilityState={{ checked: value }}
      onPress={() => onValueChange(!value)}
      style={styles.toggleRow}
    >
      <View style={{ flex: 1, gap: 3 }}>
        <Text style={styles.toggleLabel}>{label}</Text>
        {description ? (
          <Text style={styles.smallMuted}>{description}</Text>
        ) : null}
      </View>
      <View style={[styles.switchTrack, value && styles.switchTrackOn]}>
        <View style={[styles.switchThumb, value && styles.switchThumbOn]} />
      </View>
    </Pressable>
  );
}

export function ConfirmDialog({
  visible,
  title,
  message,
  confirmLabel = "ยืนยัน",
  onCancel,
  onConfirm,
}: {
  visible: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onCancel}
    >
      <View style={styles.modalShade}>
        <View style={styles.modalCard}>
          <Text accessibilityRole="header" style={styles.sectionTitle}>
            {title}
          </Text>
          <Text style={styles.bodyMuted}>{message}</Text>
          <View
            style={{
              flexDirection: "row",
              gap: 10,
              justifyContent: "flex-end",
              marginTop: 18,
            }}
          >
            <ActionButton
              label="ยกเลิก"
              tone="outline"
              onPress={onCancel}
              small
            />
            <ActionButton
              label={confirmLabel}
              tone="danger"
              onPress={onConfirm}
              small
            />
          </View>
        </View>
      </View>
    </Modal>
  );
}

export const uiStyles = StyleSheet.create({
  body: { color: C.ink, fontSize: 15, lineHeight: 23 },
  bodyMuted: { color: C.muted, fontSize: 13, lineHeight: 20 },
  row: { flexDirection: "row", alignItems: "center" },
  tag: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 99,
    backgroundColor: C.leafSoft,
  },
  tagText: { color: C.forest, fontSize: 11, fontWeight: "700" },
});

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.cream },
  scrollContent: { paddingBottom: 24 },
  inner: {
    width: "100%",
    maxWidth: 620,
    alignSelf: "center",
    paddingHorizontal: 20,
    paddingTop: 12,
    gap: 18,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    minHeight: 56,
  },
  eyebrow: { color: C.muted, fontSize: 12, fontWeight: "700", marginBottom: 3 },
  pageTitle: { color: C.ink, fontSize: 25, lineHeight: 32, fontWeight: "900" },
  headerIcon: {
    width: 42,
    height: 42,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: C.leafSoft,
  },
  sectionTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },
  sectionTitle: { color: C.ink, fontSize: 18, fontWeight: "900" },
  actionText: { color: C.forest, fontWeight: "800", fontSize: 12 },
  card: {
    backgroundColor: C.paper,
    borderRadius: 24,
    padding: 16,
    borderWidth: 1.5,
    borderColor: C.line,
    shadowColor: "#866344",
    shadowOpacity: 0.08,
    shadowRadius: 7,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  pill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 13,
    paddingVertical: 9,
    borderRadius: 99,
    backgroundColor: "#F8ECCD",
    borderWidth: 1,
    borderColor: C.line,
  },
  pillActive: { backgroundColor: C.forest, borderColor: C.forestDark },
  pillText: { color: C.forestDark, fontSize: 12, fontWeight: "700" },
  pillTextActive: { color: C.white },
  button: {
    flexDirection: "row",
    minHeight: 46,
    borderRadius: 18,
    paddingHorizontal: 16,
    borderWidth: 1.2,
    borderColor: "#376747",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  buttonSmall: { minHeight: 36, paddingHorizontal: 12, borderRadius: 15 },
  btnPrimary: { backgroundColor: C.forest },
  btnSoft: { backgroundColor: C.leafSoft, borderColor: "#B8D693" },
  btnOutline: { backgroundColor: C.paper, borderColor: C.line },
  btnDanger: { backgroundColor: C.red, borderColor: "#B7524B" },
  btnTextWhite: { color: C.white, fontWeight: "800", fontSize: 14 },
  btnTextDark: { color: C.forest, fontWeight: "800", fontSize: 14 },
  disabled: { opacity: 0.48 },
  pressed: { opacity: 0.76, transform: [{ scale: 0.98 }] },
  backHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  backButton: {
    width: 42,
    height: 42,
    borderRadius: 16,
    backgroundColor: C.paper,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1.5,
    borderColor: C.line,
  },
  backTitle: { color: C.ink, fontSize: 17, fontWeight: "800" },
  searchWrap: {
    minHeight: 46,
    paddingHorizontal: 14,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: C.line,
    backgroundColor: C.paper,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
  },
  searchInput: {
    flex: 1,
    minHeight: 44,
    color: C.ink,
    fontSize: 14,
    outlineStyle: "none" as never,
  },
  loading: {
    minHeight: 160,
    gap: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  bodyMuted: { color: C.muted, fontSize: 13, lineHeight: 20 },
  offlineBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: C.orangeSoft,
    borderColor: "#E7C276",
    borderWidth: 1.5,
    borderRadius: 18,
    padding: 11,
  },
  offlineText: {
    color: C.forestDark,
    fontSize: 12,
    fontWeight: "700",
    flex: 1,
  },
  heroPhoto: {
    overflow: "hidden",
    borderRadius: 28,
    justifyContent: "flex-end",
    backgroundColor: C.leafSoft,
  },
  heroImage: { borderRadius: 28 },
  heroShade: {
    position: "absolute",
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    backgroundColor: "rgba(66,54,38,0.25)",
  },
  fieldLabel: { color: C.ink, fontSize: 13, fontWeight: "700" },
  input: {
    minHeight: 48,
    paddingHorizontal: 14,
    borderRadius: 17,
    backgroundColor: C.paper,
    borderWidth: 1.5,
    borderColor: C.line,
    color: C.ink,
    fontSize: 14,
    outlineStyle: "none" as never,
  },
  toggleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
    paddingVertical: 13,
    borderBottomWidth: 1,
    borderBottomColor: C.line,
  },
  toggleLabel: { color: C.ink, fontSize: 14, fontWeight: "700" },
  smallMuted: { color: C.muted, fontSize: 11, lineHeight: 17 },
  switchTrack: {
    width: 46,
    height: 27,
    borderRadius: 18,
    padding: 3,
    backgroundColor: "#DFE4D9",
    justifyContent: "center",
  },
  switchTrackOn: { backgroundColor: C.forest },
  switchThumb: {
    width: 21,
    height: 21,
    borderRadius: 11,
    backgroundColor: C.white,
    alignSelf: "flex-start",
    shadowColor: "#000",
    shadowOpacity: 0.12,
    shadowRadius: 3,
    elevation: 1,
  },
  switchThumbOn: { alignSelf: "flex-end" },
  modalShade: {
    flex: 1,
    backgroundColor: "rgba(22,38,29,0.48)",
    justifyContent: "center",
    alignItems: "center",
    padding: 22,
  },
  modalCard: {
    width: "100%",
    maxWidth: 420,
    backgroundColor: C.paper,
    padding: 22,
    borderRadius: 26,
    borderWidth: 1.5,
    borderColor: C.line,
    shadowColor: "#76563C",
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 4,
    gap: 12,
  },
});
