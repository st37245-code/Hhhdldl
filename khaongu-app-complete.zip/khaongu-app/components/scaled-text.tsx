import React, { useContext } from "react";
import { StyleSheet, Text as NativeText, type TextProps } from "react-native";
import { TextScaleContext } from "@/hooks/app-store";

export function ScaledText({ style, ...props }: TextProps) {
  const largeText = useContext(TextScaleContext);
  const flattened = StyleSheet.flatten(style) ?? {};
  const scaled = largeText
    ? {
        fontSize:
          typeof flattened.fontSize === "number"
            ? Math.round(flattened.fontSize * 1.18)
            : 16,
        lineHeight:
          typeof flattened.lineHeight === "number"
            ? Math.round(flattened.lineHeight * 1.18)
            : undefined,
      }
    : undefined;
  return <NativeText {...props} style={[flattened, scaled]} />;
}
