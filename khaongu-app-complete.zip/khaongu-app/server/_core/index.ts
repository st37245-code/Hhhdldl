import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { createCorsMiddleware } from "./cors";
import { clearLegacySessionCookie } from "./cookies";
import path from "node:path";

async function startServer() {
  const app = express();
  const server = createServer(app);

  app.use(createCorsMiddleware());
  app.use(clearLegacySessionCookie());

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerStorageProxy(app);
  registerOAuthRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const webRoot = path.resolve(process.cwd(), "dist", "web");
  app.use(express.static(webRoot, { extensions: ["html"] }));
  app.get("*", (req, res, next) => {
    const isApiPath = req.path === "/api" || req.path.startsWith("/api/");
    const isStoragePath = req.path.startsWith("/manus-storage/");
    const isFilePath = Boolean(path.extname(req.path));

    if (isApiPath || isStoragePath || isFilePath) {
      next();
      return;
    }

    res.sendFile(path.join(webRoot, "index.html"), (error) => {
      if (error) next(error);
    });
  });

  const port = parseInt(process.env.PORT || "3000");
  server.listen(port, () => {
    console.log("[api] server listening");
  });
}

startServer().catch(() => {
  console.error("[api] server failed to start");
});
