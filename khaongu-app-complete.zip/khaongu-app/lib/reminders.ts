import { Platform } from "react-native";
import type { ReminderChoice } from "./models";

export type ReminderResult = "scheduled" | "denied" | "unsupported" | "failed";

export async function scheduleTaskReminder(
  title: string,
  choice: ReminderChoice,
): Promise<ReminderResult> {
  if (choice === "none") return "unsupported";
  if (Platform.OS === "web") return "unsupported";
  try {
    const Notifications = await import("expo-notifications");
    const current = await Notifications.getPermissionsAsync();
    const permission =
      current.status === "granted"
        ? current
        : await Notifications.requestPermissionsAsync();
    if (permission.status !== "granted") return "denied";
    const seconds = choice === "in-hour" ? 60 * 60 : 24 * 60 * 60;
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "ภารกิจรออยู่นะ",
        body: title,
        sound: true,
        data: { app: "khaongu" },
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
        seconds,
        repeats: false,
      },
    });
    return "scheduled";
  } catch {
    return "failed";
  }
}

export async function cancelTaskReminders(): Promise<boolean> {
  if (Platform.OS === "web") return true;
  try {
    const Notifications = await import("expo-notifications");
    await Notifications.cancelAllScheduledNotificationsAsync();
    return true;
  } catch {
    return false;
  }
}

export async function requestNotificationPermission(): Promise<ReminderResult> {
  if (Platform.OS === "web") return "unsupported";
  try {
    const Notifications = await import("expo-notifications");
    const result = await Notifications.requestPermissionsAsync();
    return result.status === "granted" ? "scheduled" : "denied";
  } catch {
    return "failed";
  }
}
