export type HatchProgressState = {
  xp: number;
  hatchProgress: number;
  unlockedSnakeIds: string[];
};

export const HATCH_ANSWERS_REQUIRED = 5;
export const SECRET_HATCH_CHANCE = 0.1;

type RandomSource = () => number;

export function applyQuizAnswer(
  state: HatchProgressState,
  correct: boolean,
  snakeOrder: string[],
  secretIds: string[] = [],
  random: RandomSource = Math.random,
): { state: HatchProgressState; hatchedId: string | null } {
  if (!correct) return { state, hatchedId: null };

  const nextProgress = state.hatchProgress + 1;
  let hatchedId: string | null = null;

  if (nextProgress >= HATCH_ANSWERS_REQUIRED) {
    const unlocked = new Set(state.unlockedSnakeIds);
    const secretSet = new Set(secretIds);
    const remaining = snakeOrder.filter((id) => !unlocked.has(id));
    const regular = remaining.filter((id) => !secretSet.has(id));
    const secret = remaining.filter((id) => secretSet.has(id));
    const pool =
      regular.length === 0 ||
      (secret.length > 0 && random() < SECRET_HATCH_CHANCE)
        ? secret
        : regular;

    if (pool.length > 0) {
      const pick = Math.min(
        pool.length - 1,
        Math.floor(random() * pool.length),
      );
      hatchedId = pool[pick];
    }
  }

  return {
    state: {
      xp: state.xp + 10,
      hatchProgress: nextProgress >= HATCH_ANSWERS_REQUIRED ? 0 : nextProgress,
      unlockedSnakeIds: hatchedId
        ? [...state.unlockedSnakeIds, hatchedId]
        : state.unlockedSnakeIds,
    },
    hatchedId,
  };
}
