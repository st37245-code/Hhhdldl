export type SnakeSpecies = {
  id: string;
  speciesId: string;
  speciesName: string;
  name: string;
  colorName: string;
  color: string;
  accent: string;
  pattern: number;
  rarity: string;
  isSecret: boolean;
  fact: string;
  safety: string;
};

type SnakeProfile = {
  id: string;
  name: string;
  pattern: number;
  fact: string;
  safety: string;
};

const snakeProfiles: SnakeProfile[] = [
  {
    id: "python-burmese",
    name: "งูหลาม",
    pattern: 0,
    fact: "ลวดลายช่วยพรางตัวให้กลมกลืนกับพื้นธรรมชาติ",
    safety: "งูป่าควรดูจากระยะปลอดภัย ไม่จับหรือรบกวน",
  },
  {
    id: "python-reticulated",
    name: "งูเหลือม",
    pattern: 1,
    fact: "ลายตาข่ายเป็นเอกลักษณ์ที่ทำให้จำแนกภาพของงูชนิดนี้ได้ง่าย",
    safety: "อย่าเข้าใกล้งูขนาดใหญ่ ให้ถอยห่างและบอกผู้ใหญ่",
  },
  {
    id: "vine-snake",
    name: "งูเขียวพระอินทร์",
    pattern: 2,
    fact: "ลำตัวเรียวสีเขียวทำให้กลมกลืนกับกิ่งไม้และใบไม้",
    safety: "มองจากระยะห่าง ไม่แหย่กิ่งไม้หรือจับสัตว์ป่า",
  },
  {
    id: "pit-viper",
    name: "งูเขียวหางไหม้",
    pattern: 3,
    fact: "งูกลุ่มนี้มีสีเขียวเด่นและมีชนิดที่มีพิษ เรียนรู้โดยไม่เข้าใกล้",
    safety: "เป็นงูพิษ ห้ามเข้าใกล้หรือจับ แจ้งผู้ใหญ่และเจ้าหน้าที่",
  },
  {
    id: "king-cobra",
    name: "งูจงอาง",
    pattern: 4,
    fact: "งูชนิดนี้มีพิษและควรเรียนรู้จากหนังสือหรือผู้เชี่ยวชาญเท่านั้น",
    safety: "งูพิษอันตราย ห้ามเข้าใกล้ ให้ผู้ใหญ่ติดต่อเจ้าหน้าที่",
  },
  {
    id: "banded-krait",
    name: "งูสามเหลี่ยม",
    pattern: 5,
    fact: "ลายปล้องสีตัดกันช่วยให้จดจำได้ และเป็นตัวอย่างเรื่องสีเตือนภัย",
    safety: "มีพิษ ห้ามเข้าใกล้หรือพยายามถ่ายภาพใกล้ ๆ",
  },
];

const regularPalettes = [
  {
    suffix: "",
    label: "สีใบไม้",
    color: "#82C967",
    accent: "#3E8750",
    pattern: 0,
    rarity: "พื้นฐาน",
  },
  {
    suffix: "-berry",
    label: "สีเบอร์รี",
    color: "#F184A9",
    accent: "#A94E79",
    pattern: 2,
    rarity: "สีพิเศษ",
  },
  {
    suffix: "-ocean",
    label: "สีคลื่นฟ้า",
    color: "#59C4D7",
    accent: "#287D98",
    pattern: 4,
    rarity: "สีพิเศษ",
  },
];

const secretPalettes = [
  { label: "สีรุ้งลับ", color: "#BF78E6", accent: "#FFD15C", pattern: 5 },
  { label: "สีฟองสบู่", color: "#F07CA8", accent: "#5CC8DA", pattern: 3 },
  { label: "สีน้ำค้างดาว", color: "#8295F0", accent: "#FFE27D", pattern: 4 },
  {
    label: "สีใบไม้เวทมนตร์",
    color: "#8DCD65",
    accent: "#EA69B2",
    pattern: 5,
  },
  { label: "สีแสงอาทิตย์", color: "#F1B84F", accent: "#835FD1", pattern: 3 },
  { label: "สีคอสมิก", color: "#6B61D5", accent: "#75DDE2", pattern: 4 },
];

export const snakes: SnakeSpecies[] = snakeProfiles.flatMap(
  (profile, profileIndex) => {
    const regular = regularPalettes.map((palette, paletteIndex) => ({
      id: palette.suffix ? `${profile.id}${palette.suffix}` : profile.id,
      speciesId: profile.id,
      speciesName: profile.name,
      name:
        paletteIndex === 0
          ? profile.name
          : `${profile.name} · ${palette.label}`,
      colorName: palette.label,
      color: palette.color,
      accent: palette.accent,
      pattern: (profile.pattern + palette.pattern) % 6,
      rarity: palette.rarity,
      isSecret: false,
      fact: profile.fact,
      safety: profile.safety,
    }));
    const secret = secretPalettes[profileIndex];
    return [
      ...regular,
      {
        id: `${profile.id}-secret`,
        speciesId: profile.id,
        speciesName: profile.name,
        name: `${profile.name} · ${secret.label}`,
        colorName: secret.label,
        color: secret.color,
        accent: secret.accent,
        pattern: (profile.pattern + secret.pattern) % 6,
        rarity: "สีซีเคร็ต",
        isSecret: true,
        fact: profile.fact,
        safety: profile.safety,
      },
    ];
  },
);
