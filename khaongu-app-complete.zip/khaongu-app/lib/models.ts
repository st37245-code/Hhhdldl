export type TaskCategory = "สำรวจ" | "เรียนรู้" | "เกม" | "อื่น ๆ";
export type ReminderChoice = "none" | "in-hour" | "tomorrow";
export type ReminderStatus =
  | "none"
  | "pending"
  | "scheduled"
  | "needs-permission"
  | "denied"
  | "unsupported"
  | "failed";

export type LearningTask = {
  id: string;
  title: string;
  category: TaskCategory;
  status: "open" | "done";
  createdAt: string;
  completedAt?: string;
  reminder: ReminderChoice;
  reminderStatus: ReminderStatus;
};

export type LearnerSettings = {
  displayName: string;
  largeText: boolean;
  reduceMotion: boolean;
  offlineDemo: boolean;
  notificationsEnabled: boolean;
};

export type AppData = {
  schemaVersion: 1;
  hasOnboarded: boolean;
  welcomeVisible: boolean;
  tasks: LearningTask[];
  xp: number;
  hatchProgress: number;
  unlockedSnakeIds: string[];
  learnedLessonIds: string[];
  settings: LearnerSettings;
};

export const taskCategories: TaskCategory[] = [
  "สำรวจ",
  "เรียนรู้",
  "เกม",
  "อื่น ๆ",
];
export const reminderChoices: ReminderChoice[] = [
  "none",
  "in-hour",
  "tomorrow",
];
export const reminderStatuses: ReminderStatus[] = [
  "none",
  "pending",
  "scheduled",
  "needs-permission",
  "denied",
  "unsupported",
  "failed",
];
