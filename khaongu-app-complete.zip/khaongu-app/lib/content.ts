import type { ImageSourcePropType } from "react-native";
import type { TaskCategory } from "./models";

export type PhotoStory = {
  id: string;
  title: string;
  caption: string;
  credit: string;
  sourceUrl: string;
  image: ImageSourcePropType;
};

export const parkPhotos: PhotoStory[] = [
  {
    id: "panorama",
    title: "ภูเขาหินปูนกับผืนน้ำ",
    caption:
      "ภูมิทัศน์เขางูเกิดจากกลุ่มภูเขาหินปูนและพื้นที่เหมืองเดิมที่มีน้ำ",
    credit: "It's better in Thailand",
    sourceUrl:
      "https://www.itsbetterinthailand.com/activities/khao-ngu-stone-park/",
    image: require("../assets/images/khaongu/park-panorama.jpg"),
  },
  {
    id: "official",
    title: "มุมมองอุทยานหินเขางู",
    caption:
      "ภาพจริงจากแหล่งข้อมูลจังหวัดราชบุรี ใช้ประกอบการเรียนรู้เรื่องภูมิประเทศ",
    credit: "องค์การบริหารส่วนจังหวัดราชบุรี",
    sourceUrl:
      "https://www.ratchaburipao.go.th/travel-single.php?slug=%E0%B8%AD%E0%B8%B8%E0%B8%97%E0%B8%A2%E0%B8%B2%E0%B8%99%E0%B8%AB%E0%B8%B4%E0%B8%99%E0%B9%80%E0%B8%82%E0%B8%B2%E0%B8%87%E0%B8%B9",
    image: require("../assets/images/khaongu/park-official.jpg"),
  },
  {
    id: "bridge",
    title: "ทางเดินชมวิว",
    caption:
      "ภาพสะพานและหน้าผาหินจากบทความท่องเที่ยว ใช้เป็นภาพประกอบ ไม่ใช่แผนที่เส้นทาง",
    credit: "Your Thai Guide",
    sourceUrl: "https://yourthaiguide.com",
    image: require("../assets/images/khaongu/park-bridge.jpg"),
  },
];

export const lessons = [
  {
    id: "quarry",
    tag: "เรื่องราว",
    title: "จากเหมืองหินสู่สวนสาธารณะ",
    body: "ภูเขาหินปูนเขางูเคยเป็นแหล่งระเบิดและย่อยหิน ต่อมาพื้นที่ได้รับการพัฒนาเป็นสวนสาธารณะและแหล่งท่องเที่ยว ให้เราเรียนรู้ว่าภูมิทัศน์เปลี่ยนแปลงได้ตามการใช้ประโยชน์ของผู้คน",
    sourceLabel: "องค์การบริหารส่วนจังหวัดราชบุรี",
    sourceUrl: parkPhotos[1].sourceUrl,
    icon: "⛰️",
  },
  {
    id: "caves",
    tag: "มรดกวัฒนธรรม",
    title: "ถ้ำที่เก็บร่องรอยศิลปะ",
    body: "บริเวณเขางูมีถ้ำสำคัญ เช่น ถ้ำฤๅษีและถ้ำฝาโถ ซึ่งมีพระพุทธรูปสลักหินและงานศิลปกรรมที่เกี่ยวข้องกับสมัยทวารวดี สถานที่เหล่านี้ช่วยให้เราเห็นร่องรอยความเชื่อและฝีมือของผู้คนในอดีต",
    sourceLabel: "เขางู — วิกิพีเดีย ภาษาไทย",
    sourceUrl:
      "https://th.wikipedia.org/wiki/%E0%B9%80%E0%B8%82%E0%B8%B2%E0%B8%87%E0%B8%B9",
    icon: "🪷",
  },
  {
    id: "nature",
    tag: "เที่ยวอย่างรับผิดชอบ",
    title: "สังเกตธรรมชาติอย่างอ่อนโยน",
    body: "รอบบึงและภูเขามีเส้นทางชมวิวและสะพานแขวนตามข้อมูลท่องเที่ยว เมื่อพบสัตว์ป่าให้ชมจากระยะห่าง ไม่ให้อาหาร และไม่พยายามเข้าใกล้หรือสัมผัส",
    sourceLabel: "It's better in Thailand",
    sourceUrl: parkPhotos[0].sourceUrl,
    icon: "🍃",
  },
];

export { snakes } from "./snakes";
export type { SnakeSpecies } from "./snakes";

export const quizQuestions: {
  prompt: string;
  options: string[];
  answer: number;
  hint: string;
}[] = [
  {
    prompt: "เขางูมีภูมิประเทศเด่นแบบใด?",
    options: ["ภูเขาหินปูน", "ทุ่งน้ำแข็ง", "ทะเลทราย"],
    answer: 0,
    hint: "มองหาหน้าผาสีอ่อนที่เห็นในภาพอุทยาน",
  },
  {
    prompt: "ก่อนพัฒนาเป็นสวนสาธารณะ พื้นที่เขางูเคยเป็นอะไร?",
    options: ["เหมืองหินปูน", "สนามบิน", "ท่าเรือ"],
    answer: 0,
    hint: "อ่านเรื่องราวการเปลี่ยนแปลงของพื้นที่",
  },
  {
    prompt: "ถ้ำใดเป็นหนึ่งในถ้ำสำคัญบริเวณเขางู?",
    options: ["ถ้ำฤๅษี", "ถ้ำมรกต", "ถ้ำปลา"],
    answer: 0,
    hint: "ชื่อถ้ำขึ้นต้นด้วยคำว่า ฤๅษี",
  },
  {
    prompt: "ถ้าเห็นสัตว์ป่า เราควรทำอย่างไร?",
    options: ["ชมจากระยะห่าง", "เข้าไปป้อนอาหาร", "จับมาเล่น"],
    answer: 0,
    hint: "ช่วยกันให้สัตว์ป่าใช้ชีวิตตามธรรมชาติ",
  },
  {
    prompt: "ศิลปกรรมในถ้ำเขางูเกี่ยวข้องกับยุคใด?",
    options: ["ทวารวดี", "สุโขทัยตอนปลายเท่านั้น", "รัตนโกสินทร์เท่านั้น"],
    answer: 0,
    hint: "เป็นศิลปะยุคต้น ๆ ในประวัติศาสตร์ไทย",
  },
];

export const mapPoints: {
  id: string;
  title: string;
  note: string;
  x: number;
  y: number;
  category: TaskCategory;
}[] = [
  {
    id: "viewpoint",
    title: "ลานชมวิว",
    note: "หยุดสังเกตภูเขาหินปูนและผืนน้ำ",
    x: 0.2,
    y: 0.25,
    category: "สำรวจ",
  },
  {
    id: "bridge",
    title: "สะพานแขวน",
    note: "จุดเดินชมวิวที่ปรากฏในข้อมูลท่องเที่ยว",
    x: 0.74,
    y: 0.34,
    category: "สำรวจ",
  },
  {
    id: "lake",
    title: "บึงหินปูน",
    note: "พื้นที่น้ำท่ามกลางแนวภูเขาหิน",
    x: 0.46,
    y: 0.58,
    category: "เรียนรู้",
  },
  {
    id: "caves",
    title: "ถ้ำโบราณ",
    note: "บริเวณถ้ำที่มีงานศิลปกรรมสำคัญ",
    x: 0.82,
    y: 0.73,
    category: "เรียนรู้",
  },
];
