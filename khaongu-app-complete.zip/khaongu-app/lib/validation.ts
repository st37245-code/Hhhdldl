import type {
  AppData,
  LearnerSettings,
  LearningTask,
  ReminderChoice,
  ReminderStatus,
  TaskCategory,
} from "./models";

const categories: TaskCategory[] = ["สำรวจ", "เรียนรู้", "เกม", "อื่น ๆ"];
const reminders: ReminderChoice[] = ["none", "in-hour", "tomorrow"];
const reminderStates: ReminderStatus[] = [
  "none",
  "pending",
  "scheduled",
  "needs-permission",
  "denied",
  "unsupported",
  "failed",
];

function record(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function stringArray(value: unknown): value is string[] {
  return (
    Array.isArray(value) &&
    value.every((item) => typeof item === "string" && item.length > 0) &&
    new Set(value).size === value.length
  );
}

function validDate(value: unknown): value is string {
  return (
    typeof value === "string" &&
    value.length > 0 &&
    Number.isFinite(Date.parse(value))
  );
}

function validTask(value: unknown): value is LearningTask {
  if (!record(value)) return false;
  return (
    typeof value.id === "string" &&
    value.id.length > 0 &&
    typeof value.title === "string" &&
    value.title.trim().length > 0 &&
    value.title.length <= 80 &&
    categories.includes(value.category as TaskCategory) &&
    (value.status === "open" || value.status === "done") &&
    validDate(value.createdAt) &&
    (value.completedAt === undefined || validDate(value.completedAt)) &&
    reminders.includes(value.reminder as ReminderChoice) &&
    (value.reminderStatus === undefined ||
      reminderStates.includes(value.reminderStatus as ReminderStatus))
  );
}

function validSettings(value: unknown): value is LearnerSettings {
  if (!record(value)) return false;
  return (
    typeof value.displayName === "string" &&
    value.displayName.length <= 24 &&
    typeof value.largeText === "boolean" &&
    typeof value.reduceMotion === "boolean" &&
    typeof value.offlineDemo === "boolean" &&
    typeof value.notificationsEnabled === "boolean"
  );
}

export function isAppData(value: unknown): value is AppData {
  if (!record(value)) return false;
  return (
    value.schemaVersion === 1 &&
    typeof value.hasOnboarded === "boolean" &&
    (value.welcomeVisible === undefined ||
      typeof value.welcomeVisible === "boolean") &&
    Array.isArray(value.tasks) &&
    value.tasks.every(validTask) &&
    Number.isSafeInteger(value.xp) &&
    (value.xp as number) >= 0 &&
    Number.isSafeInteger(value.hatchProgress) &&
    (value.hatchProgress as number) >= 0 &&
    (value.hatchProgress as number) < 5 &&
    stringArray(value.unlockedSnakeIds) &&
    value.unlockedSnakeIds.length > 0 &&
    stringArray(value.learnedLessonIds) &&
    validSettings(value.settings)
  );
}
