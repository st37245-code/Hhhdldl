import {
  ScrollViewStyleReset,
  useServerDocumentContext,
} from "expo-router/html";
import type { PropsWithChildren } from "react";

export default function Root({ children }: PropsWithChildren) {
  const { htmlAttributes, bodyAttributes, headNodes, bodyNodes } =
    useServerDocumentContext();

  return (
    <html {...htmlAttributes} lang="th">
      <head>
        {headNodes}
        <title>เขางูน่ารู้</title>
        <meta
          name="description"
          content="เรียนรู้ประวัติ แผนผัง และฉากจำลอง 3 มิติของอุทยานหินเขางู พร้อมภารกิจและเกมสะสมงูน้อย"
        />
      </head>
      <body {...bodyAttributes}>
        <ScrollViewStyleReset />
        {children}
        {bodyNodes}
      </body>
    </html>
  );
}
