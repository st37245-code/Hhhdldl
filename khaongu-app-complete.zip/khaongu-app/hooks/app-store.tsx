import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Platform } from "react-native";

import { snakes } from "@/lib/content";
import { applyQuizAnswer } from "@/lib/game-logic";
import type {
  AppData,
  LearningTask,
  ReminderChoice,
  ReminderStatus,
  TaskCategory,
} from "@/lib/models";
import { isAppData } from "@/lib/validation";

const STORAGE_KEY = "khaongu.student.v1";

function initialData(): AppData {
  const now = new Date().toISOString();
  return {
    schemaVersion: 1,
    hasOnboarded: false,
    welcomeVisible: true,
    tasks: [
      {
        id: "starter-story",
        title: "อ่านเรื่องราวถ้ำโบราณ",
        category: "เรียนรู้",
        status: "open",
        createdAt: now,
        reminder: "none",
        reminderStatus: "none",
      },
      {
        id: "starter-map",
        title: "เลือกจุดที่อยากสำรวจบนแผนที่",
        category: "สำรวจ",
        status: "open",
        createdAt: now,
        reminder: "none",
        reminderStatus: "none",
      },
    ],
    xp: 0,
    hatchProgress: 0,
    unlockedSnakeIds: [snakes[0].id],
    learnedLessonIds: [],
    settings: {
      displayName: "นักสำรวจ",
      largeText: false,
      reduceMotion: false,
      offlineDemo: false,
      notificationsEnabled: false,
    },
  };
}

type AppStore = {
  data: AppData;
  ready: boolean;
  storageError: "read" | "write" | null;
  isOffline: boolean;
  lastDeleted: LearningTask | null;
  completeOnboarding: () => void;
  dismissOnboarding: () => void;
  replayOnboarding: () => void;
  addTask: (
    title: string,
    category: TaskCategory,
    reminder: ReminderChoice,
  ) => LearningTask;
  setReminderStatus: (taskId: string, status: ReminderStatus) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;
  undoDelete: () => void;
  clearUndo: () => void;
  markLessonLearned: (id: string) => void;
  answerQuiz: (correct: boolean) => string | null;
  updateSettings: (patch: Partial<AppData["settings"]>) => void;
  recoverStorage: (reset?: boolean) => Promise<void>;
};

const StoreContext = createContext<AppStore | null>(null);
export const TextScaleContext = createContext(false);

export function AppStoreProvider({ children }: React.PropsWithChildren) {
  const [data, setData] = useState<AppData>(() => initialData());
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState<"read" | "write" | null>(
    null,
  );
  const [lastDeleted, setLastDeleted] = useState<LearningTask | null>(null);
  const [networkOnline, setNetworkOnline] = useState(true);
  const dataRef = useRef(data);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!active) return;
        if (raw) {
          const parsed: unknown = JSON.parse(raw);
          if (!isAppData(parsed)) throw new Error("Invalid app data");
          const tasks = parsed.tasks.map((task) => ({
            ...task,
            reminderStatus:
              task.reminderStatus ??
              (task.reminder === "none" ? "none" : "needs-permission"),
          }));
          setData({
            ...parsed,
            tasks,
            welcomeVisible: parsed.welcomeVisible ?? !parsed.hasOnboarded,
          });
        }
        setReady(true);
      })
      .catch(() => {
        if (!active) return;
        setStorageError("read");
        setReady(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    dataRef.current = data;
  }, [data]);
  useEffect(() => {
    if (!ready || storageError) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data)).catch(() =>
      setStorageError("write"),
    );
  }, [data, ready, storageError]);
  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    const update = () => setNetworkOnline(window.navigator.onLine);
    update();
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);

  const completeOnboarding = useCallback(
    () =>
      setData((current) => ({
        ...current,
        hasOnboarded: true,
        welcomeVisible: false,
      })),
    [],
  );
  const dismissOnboarding = useCallback(
    () => setData((current) => ({ ...current, welcomeVisible: false })),
    [],
  );
  const replayOnboarding = useCallback(
    () =>
      setData((current) => ({
        ...current,
        hasOnboarded: false,
        welcomeVisible: true,
      })),
    [],
  );

  const addTask = useCallback(
    (title: string, category: TaskCategory, reminder: ReminderChoice) => {
      const task: LearningTask = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        title: title.trim(),
        category,
        reminder,
        status: "open",
        createdAt: new Date().toISOString(),
        reminderStatus: reminder === "none" ? "none" : "pending",
      };
      setData((current) => ({ ...current, tasks: [task, ...current.tasks] }));
      return task;
    },
    [],
  );

  const setReminderStatus = useCallback(
    (taskId: string, status: ReminderStatus) => {
      setData((current) => ({
        ...current,
        tasks: current.tasks.map((task) =>
          task.id === taskId ? { ...task, reminderStatus: status } : task,
        ),
      }));
    },
    [],
  );

  const toggleTask = useCallback((id: string) => {
    setData((current) => ({
      ...current,
      tasks: current.tasks.map((task) =>
        task.id === id
          ? {
              ...task,
              status: task.status === "open" ? "done" : "open",
              completedAt:
                task.status === "open" ? new Date().toISOString() : undefined,
            }
          : task,
      ),
      xp: current.tasks.some((task) => task.id === id && task.status === "open")
        ? current.xp + 5
        : current.xp,
    }));
  }, []);

  const deleteTask = useCallback((id: string) => {
    const found = dataRef.current.tasks.find((task) => task.id === id);
    if (!found) return;
    setLastDeleted(found);
    setData((current) => ({
      ...current,
      tasks: current.tasks.filter((task) => task.id !== id),
    }));
  }, []);
  const undoDelete = useCallback(() => {
    if (!lastDeleted) return;
    setData((current) => ({
      ...current,
      tasks: [lastDeleted, ...current.tasks],
    }));
    setLastDeleted(null);
  }, [lastDeleted]);
  const clearUndo = useCallback(() => setLastDeleted(null), []);
  const markLessonLearned = useCallback((id: string) => {
    setData((current) =>
      current.learnedLessonIds.includes(id)
        ? current
        : {
            ...current,
            learnedLessonIds: [...current.learnedLessonIds, id],
            xp: current.xp + 8,
          },
    );
  }, []);
  const answerQuiz = useCallback((correct: boolean) => {
    const current = dataRef.current;
    const outcome = applyQuizAnswer(
      current,
      correct,
      snakes.map((snake) => snake.id),
      snakes.filter((snake) => snake.isSecret).map((snake) => snake.id),
    );
    if (correct) {
      const next = { ...current, ...outcome.state };
      dataRef.current = next;
      setData(next);
    }
    return outcome.hatchedId;
  }, []);
  const updateSettings = useCallback(
    (patch: Partial<AppData["settings"]>) =>
      setData((current) => ({
        ...current,
        settings: { ...current.settings, ...patch },
      })),
    [],
  );
  const recoverStorage = useCallback(
    async (reset = false) => {
      try {
        if (reset) {
          await AsyncStorage.removeItem(STORAGE_KEY);
          setData(initialData());
        } else if (storageError === "read") {
          const raw = await AsyncStorage.getItem(STORAGE_KEY);
          if (raw) {
            const parsed: unknown = JSON.parse(raw);
            if (!isAppData(parsed)) throw new Error("Invalid app data");
            setData({
              ...parsed,
              welcomeVisible: parsed.welcomeVisible ?? !parsed.hasOnboarded,
              tasks: parsed.tasks.map((task) => ({
                ...task,
                reminderStatus:
                  task.reminderStatus ??
                  (task.reminder === "none" ? "none" : "needs-permission"),
              })),
            });
          } else setData(initialData());
        } else {
          await AsyncStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(dataRef.current),
          );
        }
        setStorageError(null);
        setLastDeleted(null);
        setReady(true);
      } catch {
        setStorageError(storageError === "read" ? "read" : "write");
      }
    },
    [storageError],
  );

  const value = useMemo<AppStore>(
    () => ({
      data,
      ready,
      storageError,
      isOffline: data.settings.offlineDemo || !networkOnline,
      lastDeleted,
      completeOnboarding,
      dismissOnboarding,
      replayOnboarding,
      addTask,
      setReminderStatus,
      toggleTask,
      deleteTask,
      undoDelete,
      clearUndo,
      markLessonLearned,
      answerQuiz,
      updateSettings,
      recoverStorage,
    }),
    [
      data,
      ready,
      storageError,
      networkOnline,
      lastDeleted,
      completeOnboarding,
      dismissOnboarding,
      replayOnboarding,
      addTask,
      setReminderStatus,
      toggleTask,
      deleteTask,
      undoDelete,
      clearUndo,
      markLessonLearned,
      answerQuiz,
      updateSettings,
      recoverStorage,
    ],
  );

  return (
    <StoreContext.Provider value={value}>
      <TextScaleContext.Provider value={data.settings.largeText}>
        {children}
      </TextScaleContext.Provider>
    </StoreContext.Provider>
  );
}

export function useAppStore() {
  const context = useContext(StoreContext);
  if (!context)
    throw new Error("useAppStore must be used inside AppStoreProvider");
  return context;
}
